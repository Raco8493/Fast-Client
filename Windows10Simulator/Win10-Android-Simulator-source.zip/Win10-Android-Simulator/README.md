# Windows 10 Android Simulator (unofficial)

**A usable Windows 10-inspired desktop UI for Android. Not a Windows OS emulator.**

مشروع أندرويد تجريبي بواجهة شبه Windows 10. مش بيثبت ويندوز ولا بيشغّل برامج Windows بصيغة EXE.

## Features / المميزات
- Windows-inspired wallpaper, desktop, Start menu, search, taskbar and clock.
- Touch-draggable, minimizable/maximizable windows and task view.
- File Explorer with locally saved virtual folders and .txt files.
- Notepad (autosave), Calculator, Paint, demo Command Prompt, settings, Recycle Bin.
- Browser button opens real URLs in your installed Android browser.
- Lockscreen, themes and accent colors.
- **Offline-first**, no account, no permissions, no trackers.

## Fastest way to try / التجربة السريعة
Open `app/src/main/assets/index.html` in a desktop or Android browser. It is a web preview of the native app's desktop interface (some browser file permissions/download handling vary).

## Build APK / عمل APK
1. Install Android Studio (JDK 17+, Android SDK Platform 35).
2. Open this **project directory** as a project (not the ZIP itself).
3. Sync Gradle (Android Gradle Plugin 8.9.2; Gradle 8.11.1).
4. `Build > Build APK(s)` or run `gradle assembleDebug` if Gradle 8.11.1 is installed.
5. APK path: `app/build/outputs/apk/debug/app-debug.apk`.

> This archive includes Gradle project files but does not bundle a Gradle wrapper JAR. Android Studio may ask to configure a local Gradle installation; you can install Gradle 8.11.1 or generate the wrapper with `gradle wrapper --gradle-version 8.11.1`.

## GitHub Actions build
The GitHub branch also has a workflow at `.github/workflows/build-win10-android.yml` that installs Java/Gradle/SDK, builds this archive and uploads a debug APK as a workflow artifact when run. GitHub Actions must be enabled on the repository for this to work.

## Technical notes
- Java Android `Activity` + `WebView` containing HTML/CSS/JavaScript. No third-party runtime dependencies in the app.
- All virtual notes and file contents are stored inside WebView localStorage, **not** real device folders.
- Android back key closes open UI panels/windows; browser navigation is delegated to Android.
- Performance should be adequate on ordinary modern tablets, but it is not a guarantee for all phones.
- This is an original educational UI demo and is not affiliated with Microsoft.

## Security boundaries
No Internet permission required by the app. The demo browser uses an Android `ACTION_VIEW` intent to open HTTP(S) URLs outside the WebView. JavaScript native bridge only offers opening a validated HTTP(S) URL and closing the Activity. No executable file launching is supported.
